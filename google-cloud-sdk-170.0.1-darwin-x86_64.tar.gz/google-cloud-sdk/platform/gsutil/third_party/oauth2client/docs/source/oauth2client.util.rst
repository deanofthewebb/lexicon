oauth2client.util module
========================

.. automodule:: oauth2client.util
    :members:
    :undoc-members:
    :show-inheritance:
